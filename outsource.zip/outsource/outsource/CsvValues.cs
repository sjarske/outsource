﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace outsource
{
    public class CsvValues
    {
        string id;
        string name;
        string favfood;
        bool likesausage;

        public static CsvValues FromCsv(string csvLine)
        {
            string[] values = csvLine.Split(',');
            CsvValues csvValues = new CsvValues();
            csvValues.id = (values[0]);
            csvValues.name = (values[1]);
            csvValues.favfood = (values[2]);
            csvValues.likesausage = Convert.ToBoolean(values[3]);

            return csvValues;
        }
    }
}
