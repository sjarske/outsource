﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace outsource
{
    interface ITestDataReader
    {

        /// <summary>
        /// Returns object with data at the specified index
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="model">empty instance of a model</param>
        /// <param name="index">specified index</param>
        /// <returns></returns>
        T FillModelFromData<T>(T model, int index);


        /// <summary>
        /// Returns a list with filled objects of type
        /// </summary>
        /// <typeparam name="T">Model type</typeparam>
        /// <param name="objectList"> an empty list of the specified type</param>
        /// <returns></returns>
        IList<T> FillListWithObjects<T>(List<T> objectList);

        /// <summary>
        /// Returns a list with objects within the specified range from the index
        /// </summary>
        /// <typeparam name="T">Model type</typeparam>
        /// <param name="objectList"> Empty list</param>
        /// <param name="index"> starting index. (inclusive)</param>
        /// <param name="range">amount of objects from index</param>
        /// <returns></returns>
        IList<T> FillListWithObjects<T>(List<T> objectList, int index, int range);
    }
}
