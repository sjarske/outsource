using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace outsource
{
    class Program
    {
        static void Main(string[] args)
        {
            //veranderd de csv file in een C# class
            string InputFilePath = @"C:\Users\sjors\Desktop\Outsourcing\VoorbeeldKlasse.csv";
            string OutputFilePath = @"C:\Users\sjors\Desktop\Outsourcing\VoorbeeldKlasse.cs";

            var cSharpClass = CsvToClass.CSharpClassCodeFromCsvFile(InputFilePath, ",", "[DelimitedRecord(\",\")]", "[FieldOptional()]");
            File.WriteAllText(OutputFilePath, cSharpClass);

            //veranderd de waardes in de csv file in losse values
            List<CsvValues> values = File.ReadAllLines(InputFilePath)
                               .Skip(1)
                               .Select(v => CsvValues.FromCsv(v))
                               .ToList();
        }
    }
}
