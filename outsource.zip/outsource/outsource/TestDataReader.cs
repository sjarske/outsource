﻿using System;
using System.Collections.Generic;

namespace outsource
{
    public class TestDataReader : ITestDataReader
    {
        public IList<T> FillListWithObjects<T>(List<T> objectList)
        {
            throw new NotImplementedException();
        }

        public IList<T> FillListWithObjects<T>(List<T> objectList, int index, int range)
        {
            throw new NotImplementedException();
        }

        public T FillModelFromData<T>(T model, int index)
        {
            throw new NotImplementedException();
        }
    }
}
